---
created: 2024-03-09 12:43
tags: 📚독서, 국내도서, IT모바일, 컴퓨터공학, 컴퓨터구조일반
title: 컴퓨터 프로그램의 구조와 해석：SICP
author: 해럴드 애빌슨, 제럴드 제이 서스먼, 줄리 서스먼, 김재우, 안윤호, 김수정, 김정민, 이광근
category: 국내도서
total_page: 887
publish_date: 2016-01-30
cover_url: https://image.yes24.com/momo/TopCate690/MidCate003/68921432.jpg
status: 🟥 읽을 예정
start_read_date: 2024-03-09
finish_read_date: -
my_rate:
book_note: ❌
---



# 컴퓨터 프로그램의 구조와 해석：SICP



