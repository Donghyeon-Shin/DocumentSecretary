---
created: 2024-03-09 12:39
tags: 📚독서, 국내도서, IT모바일, 컴퓨터공학, 소프트웨어공학, 개발방법론
title: Clean Code 클린 코드：애자일 소프트웨어 장인 정신
author: 로버트 C. 마틴, 박재호, 이해영
category: 국내도서
total_page: 584
publish_date: 2013-12-24
cover_url: https://image.yes24.com/goods/11681152/XL
status: 🟦 읽는 중
start_read_date: 2024-03-04
finish_read_date: -
my_rate: 
book_note: ❌
---

# Clean Code 클린 코드：애자일 소프트웨어 장인 정신

